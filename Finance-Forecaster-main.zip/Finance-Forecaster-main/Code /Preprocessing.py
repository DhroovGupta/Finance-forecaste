ma_day = [10, 20, 50]

for ma in ma_day:
    for company in company_list:
        column_name = f"MA for {ma} days"
        company[column_name] = company['Adj Close'].rolling(ma).mean()

for company in company_list:
    company['Daily Return'] = company['Adj Close'].pct_change()
